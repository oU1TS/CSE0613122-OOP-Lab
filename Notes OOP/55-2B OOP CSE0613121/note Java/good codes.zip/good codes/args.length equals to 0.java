package p07.finalterm;

public class Main{
    public static void main(String[] args) {
//int a = args.length(); //not length with ( )
        int a = args.length;

System.out.println(a); // 0
System.out.println(args.length); // 0 
    }
}
